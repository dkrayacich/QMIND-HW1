import torch
import torch.nn.functional as F
from torchvision import datasets, transforms
import torch.nn as nn
import matplotlib.pyplot as plt
from torchsummary import summary

# transform = transforms.Compose([transforms.ToTensor()])
# mnist_data = datasets.MNIST(root='./data', train=True, download=True, transform=transform)

# # Prompt the user for an index
# while True:
#     try:
#         index = int(input("Enter an index between 0 and 59999: "))
#         if 0 <= index <= 59999:
#             break
#         else:
#             print("Index out of range. Please try again.")
#     except ValueError:
#         print("Invalid input. Please enter a valid integer.")
#
# # Get the corresponding image and label
# plt.imshow(mnist_data.data[index], cmap='gray')
# plt.show()

class autoencoderMLP4Layer(nn.Module):
    def __init__(self, N_input=784, N_bottleneck=8, N_output=784):
        super(autoencoderMLP4Layer, self).__init__()

        self.encoder = nn.Sequential(
            nn.Linear(N_input, 392),
            nn.ReLU(),
            nn.Linear(392, N_bottleneck),
            nn.ReLU()
        )

        self.decoder = nn.Sequential(
            nn.Linear(N_bottleneck, 392),
            nn.ReLU(),
            nn.Linear(392, N_output),
            nn.Sigmoid()
        )
        pass

    def forward(self, X):
        X = self.encoder(X)
        X = self.decoder(X)
        return X



model = autoencoderMLP4Layer()

summary(model, (1,784))




