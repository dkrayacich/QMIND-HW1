import torch
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from torchvision.datasets import MNIST
from torch.utils.data import DataLoader
from model import autoencoderMLP4Layer  # Adjust the import based on your project structure

# Define the device
device = 'cuda' if torch.cuda.is_available() else 'cpu'

# Load the MNIST test dataset
test_transform = transforms.Compose([
    transforms.ToTensor()
])

test_set = MNIST('./data/mnist', train=False, download=True, transform=test_transform)
test_loader = DataLoader(test_set, batch_size=64, shuffle=False)

# Instantiate the model and load trained weights
N_input = 28 * 28  # MNIST image size
N_output = N_input
bottleneck_size = 8  # or whatever you used for training
model = autoencoderMLP4Layer(N_input=N_input, N_bottleneck=bottleneck_size, N_output=N_output)
model.load_state_dict(torch.load('MLP.8.pth'))  # Load your trained model weights
model.to(device)
model.eval()  # Set the model to evaluation mode


# Function to visualize original and reconstructed images
def visualize_reconstruction(test_loader, model):
    with torch.no_grad():  # Disable gradient calculation
        for data, _ in test_loader:
            data = data.view(-1, 28 * 28).to(device)  # Flatten the images and move to device
            reconstructed = model(data)  # Get the reconstructed images

            # Move data back to CPU for visualization
            data = data.cpu().numpy()
            reconstructed = reconstructed.cpu().numpy()

            # Plotting
            n = 8  # Number of images to display
            plt.figure(figsize=(12, 4))
            for i in range(n):
                # Original images
                plt.subplot(2, n, i + 1)
                plt.imshow(data[i].reshape(28, 28), cmap='gray')
                plt.axis('off')
                plt.title('Original')

                # Reconstructed images
                plt.subplot(2, n, i + 1 + n)
                plt.imshow(reconstructed[i].reshape(28, 28), cmap='gray')
                plt.axis('off')
                plt.title('Reconstructed')

            plt.show()
            break  # Display only the first batch


# Call the visualization function
visualize_reconstruction(test_loader, model)